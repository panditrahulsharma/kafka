## use this link for oops
```


https://towardsdatascience.com/kafka-elasticsearch-kibana-and-python-e6e72598c1f3
```
## index in kibana
```
after creating index in elastic search make sure you have also create same index in kibana with *
```
